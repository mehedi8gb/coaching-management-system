<?php

namespace Modules\ParentRegistration\Entities;

use Illuminate\Database\Eloquent\Model;

class SmRegistrationSetting extends Model
{
    protected $fillable = [];
}
