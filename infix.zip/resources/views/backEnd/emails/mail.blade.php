Hello!,
<br><br>

<strong>{{$data['description']}}</strong><br>
<br>
Thanks<br>
<strong>Team</strong>
